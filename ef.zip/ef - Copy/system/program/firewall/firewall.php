<?php
class firewall extends ef{
	public function __construct(){
		
	}
	public function init($ef){
		
	}
}