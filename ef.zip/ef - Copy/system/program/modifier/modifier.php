<?php
class modifier extends ef{
	public function __construct(){
		
	}
	public function init($ef){
		$this->ef = $ef;
	}
}