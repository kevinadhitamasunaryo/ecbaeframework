<?php
class render extends ef{
	public function __construct(){
		
	}
	public function init($ef){
		
	}
}