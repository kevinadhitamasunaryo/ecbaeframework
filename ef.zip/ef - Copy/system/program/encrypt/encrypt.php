<?php
class encrypt extends ef{
	public function __construct(){
		
	}
	public function init($ef){
		
	}
}