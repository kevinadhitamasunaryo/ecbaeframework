<?php
function getWidget($str){
	
}