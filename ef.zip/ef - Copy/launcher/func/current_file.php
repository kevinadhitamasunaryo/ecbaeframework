<?php
function current_file(){
	$
}