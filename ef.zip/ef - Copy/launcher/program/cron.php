<?php
class cron extends ef{
	public function __construct(){
		
	}
}