<?php
$launchers = array(
	'cron',
	'engine',
	'report',
	'display'
);

$systems = array(
	'build',
	'firewall',
	'decrypt',
	'grab',
	'classify',
	'retrieve',
	'trigger',
	'middle',
	'site',
	'page',
	'content',
	'modifier',
	'replace',
	'render',
	'decor',
	'encrypt',
	'output'
);

$build = array(
	'build'
);

$firewall = array(
	'firewall'
);
$decrypt = array(
	'decrypt'
);
$grab = array(
	'grab'
);
$classify = array(
	'classify'
);
$retrieve = array(
	'retrieve'
);
$trigger = array(
	'trigger'
);
$middle = array(
	'middle'
);
$site = array(
	'site'
);
$page = array(
	'page'
);
$content = array(
	'content'
);
$modifier = array(
	'modifier'
);
$replace = array(
	'replace'
);
$render = array(
	'render'
);
$decor = array(
	'decor'
);
$encrypt = array(
	'encrypt'
);
$output = array(
	'output'
);