<?php
/*
echo PAGE . PHP_EOL;
echo URL_ADDR . PHP_EOL;
echo URL_DIR . PHP_EOL;
echo URL_END . PHP_EOL;
*/
